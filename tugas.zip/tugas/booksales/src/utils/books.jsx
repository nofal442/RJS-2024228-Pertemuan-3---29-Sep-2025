const books = [
  {
    id: 1,
    title: "JavaScript untuk Pemula",
    author: "Andi Prasetyo",
    description: "Panduan dasar JavaScript untuk pemula.",
    image: "https://example.com/js-pemula.jpg"
  },
  {
    id: 2,
    title: "React Modern",
    author: "Dina Sari",
    description: "Membuat aplikasi React dengan pendekatan modern.",
    image: "https://example.com/react-modern.jpg"
  },
  {
    id: 3,
    title: "Mastering CSS",
    author: "Rudi Hartono",
    description: "Teknik lanjutan untuk styling dengan CSS.",
    image: "https://example.com/css-master.jpg"
  },
  {
    id: 4,
    title: "HTML5 Essentials",
    author: "Siti Nurhaliza",
    description: "Dasar-dasar HTML5 untuk web development.",
    image: "https://example.com/html5.jpg"
  },
  {
    id: 5,
    title: "Node.js Fundamentals",
    author: "Budi Santoso",
    description: "Belajar backend dengan Node.js.",
    image: "https://example.com/nodejs.jpg"
  },
  {
    id: 6,
    title: "UI/UX Design Thinking",
    author: "Rina Kusuma",
    description: "Mendesain antarmuka yang intuitif dan menarik.",
    image: "https://example.com/uiux.jpg"
  },
  {
    id: 7,
    title: "SQL & Database",
    author: "Tono Wijaya",
    description: "Mengenal konsep database dan SQL.",
    image: "https://example.com/sql.jpg"
  },
  {
    id: 8,
    title: "Git & Version Control",
    author: "Lina Mulyani",
    description: "Mengelola proyek dengan Git dan GitHub.",
    image: "https://example.com/git.jpg"
  },
  {
    id: 9,
    title: "Bootstrap Masterclass",
    author: "Eko Ramdani",
    description: "Membuat layout responsif dengan Bootstrap.",
    image: "https://example.com/bootstrap.jpg"
  }
];

export default books;