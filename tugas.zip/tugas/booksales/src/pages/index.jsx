import Bestseller from "../components/shared/bestseller";
import Contact from "../components/shared/contact";
import Footer from "../components/shared/footer";
import Header from "../components/shared/Header";
import Hero from "../components/shared/Hero";
import Teamsection from "../components/shared/team";

export default function Home (){
    return (
        <>
     <Header/>
      {/* Hero Section */}
    <Hero/>
      {/* Best Seller Section */}
    <Bestseller/>

      {/* Team Section */}
    <Teamsection/>

      {/* Contact Section */}
    <Contact/>

      {/* Footer */}
    <Footer/>
        </>
    )
}