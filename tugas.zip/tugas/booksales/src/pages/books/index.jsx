import Headers from "../../components/shared/Header";
import Footer from "../../components/shared/footer";
import books from "../../utils/books";

export default function Books() {
  return (
    <>
      <Headers />
      <section className="py-5 bg-white text-center">
        <div className="container">
          <h2 className="fw-light">Semua Buku</h2>
          <p className="lead text-muted">Jelajahi koleksi lengkap buku yang tersedia di toko kami.</p>
          <div className="row row-cols-1 row-cols-md-3 g-4 mt-4">
            {books.map((book) => (
              <div className="col" key={book.id}>
                <div className="card h-100 shadow-sm">
                  <img src={book.image} className="card-img-top" alt={book.title} />
                  <div className="card-body">
                    <h5 className="card-title">{book.title}</h5>
                    <p className="card-text">{book.description}</p>
                    <p className="text-muted"><em>{book.author}</em></p>
                  </div>
                  <div className="card-footer d-flex justify-content-between align-items-center">
                    <button className="btn btn-sm btn-outline-primary">Detail</button>
                    <small className="text-muted">ID: {book.id}</small>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}