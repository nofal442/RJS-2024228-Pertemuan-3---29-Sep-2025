export default function Hero () {
    return (
        <>
        <div className="container text-center rounded-2 border shadow p-5 my-4">
        <h1 className="display-5 fw-bold">Atomic Habits</h1>
        <p className="lead">Perubahan kecil yang memberikan hasil luar biasa. Cara mudah dan terbukti untuk membentuk kebiasaan baik.</p>
        <div className="d-grid gap-2 d-sm-flex justify-content-sm-center mb-4">
          <button type="button" className="btn btn-primary btn-lg px-4 me-md-2">Buy Now</button>
          <button type="button" className="btn btn-outline-secondary btn-lg px-4">Detail</button>
        </div>
        <img src="https://picsum.photos/720/400" className="img-fluid rounded" alt="Atomic Habits Cover" />
      </div>
        </>
    )
}