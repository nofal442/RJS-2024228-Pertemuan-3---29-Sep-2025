export default function Team() {
    return (
        <>
        <section className="py-5 container">
        <h2 className="text-center mb-4">Our Team</h2>
        <div className="row row-cols-1 row-cols-md-3 g-4">
          {["Acer", "Nadia", "Rizky"].map((name, index) => (
            <div className="col" key={index}>
              <div className="card h-100 text-center">
                <img src={`https://i.pravatar.cc/300?img=${index + 1}`} className="card-img-top rounded-circle mx-auto mt-3" style={{ width: "150px", height: "150px" }} alt={name} />
                <div className="card-body">
                  <h5 className="card-title">{name}</h5>
                  <p className="card-text">Frontend Developer passionate about clean UI and user experience.</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
        </>
    )
}