import React, { useState } from "react";
import booksData from "../../../utils/books"; // sesuaikan path jika perlu

export default function Bestseller() {
  const [books, setBooks] = useState(booksData);

  const addBook = () => {
    const newBook = {
      id: books.length + 1,
      title: `Buku Tambahan ${books.length + 1}`,
      author: "Penulis Baru",
      description: "Deskripsi buku tambahan yang ditambahkan secara dinamis.",
      image: `https://picsum.photos/300/200?random=${books.length + 1}`
    };
    setBooks([...books, newBook]);
  };

  return (
    <section className="py-5 bg-light text-center">
      <div className="container">
        <h2 className="fw-light">Best Seller Collection</h2>
        <p className="lead text-muted">
          Temukan buku-buku terbaik yang telah menginspirasi jutaan pembaca di seluruh dunia.
        </p>
        <button className="btn btn-primary mb-4" onClick={addBook}>
          Tambah Buku
        </button>
        <div className="row row-cols-1 row-cols-md-3 g-4 mt-2">
          {books.map((book) => (
            <div className="col" key={book.id}>
              <div className="card h-100 shadow-sm">
                <img src={book.image} className="card-img-top" alt={book.title} />
                <div className="card-body">
                  <h5 className="card-title">{book.title}</h5>
                  <p className="card-text">{book.description}</p>
                </div>
                <div className="card-footer d-flex justify-content-between align-items-center">
                  <button className="btn btn-sm btn-outline-primary">View</button>
                  <small className="text-muted">Updated recently</small>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}