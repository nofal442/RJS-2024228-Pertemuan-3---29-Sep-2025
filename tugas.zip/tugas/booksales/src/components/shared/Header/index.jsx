import { Link } from "react-router-dom";

export default function Header() {
  return (
    <nav className="d-flex flex-wrap align-items-center justify-content-md-between py-3 border-bottom container">
      <Link to="/" className="d-inline-flex align-items-center text-decoration-none">
        <i className="fa-solid fa-book fa-2xl" style={{ color: "#74C0FC" }}></i>
        <span className="nav-link px-2 fw-bold">Bookstore</span>
      </Link>
      <ul className="nav nav-pills justify-content-center mb-md-0">
        <li><Link to="/" className="nav-link px-2">Home</Link></li>
        <li><Link to="/books" className="nav-link px-2">Book</Link></li>
        <li><Link to="/team" className="nav-link px-2">Team</Link></li>
        <li><Link to="/contact" className="nav-link px-2">Contact</Link></li>
      </ul>
      <div className="text-end">
        <button type="button" className="btn btn-outline-primary me-2">Login</button>
        <button type="button" className="btn btn-primary">Register</button>
      </div>
    </nav>
  );
}