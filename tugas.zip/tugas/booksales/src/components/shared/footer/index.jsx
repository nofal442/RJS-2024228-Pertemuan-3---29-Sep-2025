export default function Footer () {
    return (
        <>
        <footer className="py-4 border-top text-center">
        <p className="text-muted mb-0">© 2025 NF ACADEMY. All rights reserved.</p>
      </footer>
        </>
    )
}