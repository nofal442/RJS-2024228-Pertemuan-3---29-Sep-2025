import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages";
import Books from "./pages/books";
import Contact from "./components/shared/contact";
import Team from "./components/shared/team";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route index element={<Home />} />
        <Route path="books" element={<Books />} />
        <Route path="contact" element={<Contact />} />
        <Route path="team" element={<Team/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;